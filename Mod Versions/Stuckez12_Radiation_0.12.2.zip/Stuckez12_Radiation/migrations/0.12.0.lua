game.print("------------------------ Stuckez12 Radiation Version 0.12.# Announcement ------------------------")
game.print("|")
game.print("Version 0.12.# brings a new feature to radiation where chests now have long distance reach.")
game.print("However this feature will not be applied to pre existing chests due to UPS limitations.")
game.print("This feature will work for any chest placed after the update and behave as expected.")
game.print("So if you want your existing chests to be registed with the new feature they will have to be replaced.")
game.print("|")
game.print("Alternatively you can use the following command below to add all existing chests to the new feature.")
game.print("/chest_migrate")
game.print("However use at your own risk if your save file is large/megabase size as this will execute in one tick.")
game.print("Once executed your game will freeze as it adds all chests to memory.")
game.print("|")
game.print("I (Stuckez12) apologise for this inconvenience.")


storage.chunk_update_limit = {
    max = 12,
    current = 0
}
