local function is_item(name) return game.item_prototypes[name] ~= nil end
