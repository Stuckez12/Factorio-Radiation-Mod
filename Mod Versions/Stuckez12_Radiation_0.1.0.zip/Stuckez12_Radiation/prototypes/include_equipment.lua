require("prototypes.equipment.radiation_absorption")
require("prototypes.equipment.radiation_reduction")
